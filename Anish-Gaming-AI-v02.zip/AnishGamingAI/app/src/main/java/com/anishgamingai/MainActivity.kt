package com.anishgamingai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var report: TextView
    private lateinit var issueGroup: RadioGroup
    private var selectedIssue = "Aim overshoots"
    private val videoRequest = 101
    private val captureRequest = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 36, 32, 32)
            setBackgroundColor(0xFF10131B.toInt())
        }

        fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, 8, 0, 8)
            }

        page.addView(text("ANISH GAMING AI", 26f, 0xFF71E6B1.toInt()))
        page.addView(text("Free Fire coach • Samsung Galaxy M34 5G • 6 GB RAM", 14f, 0xFFB9C2D0.toInt()))
        page.addView(text("1. Gameplay analysis", 19f, 0xFF71E6B1.toInt()))

        status = text("Ready. Choose a recording or start approved live screen capture.", 14f, 0xFFFFD98A.toInt())
        page.addView(status)

        page.addView(Button(this).apply {
            text = "Select gameplay recording"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "video/*"
                }
                startActivityForResult(intent, videoRequest)
            }
        }, buttonParams())

        page.addView(Button(this).apply {
            text = "Start live screen capture"
            setOnClickListener { requestScreenCapture() }
        }, buttonParams())

        page.addView(text("2. What happens to your aim?", 19f, 0xFF71E6B1.toInt()))
        issueGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            listOf(
                "Aim overshoots",
                "Aim stops below the head",
                "Crosshair shakes / feels unstable",
                "Aim moves too slowly",
                "Not sure"
            ).forEachIndexed { index, label ->
                addView(RadioButton(this@MainActivity).apply {
                    id = 200 + index
                    text = label
                    textSize = 14f
                    setTextColor(0xFFFFFFFF.toInt())
                    isChecked = index == 0
                })
            }
            setOnCheckedChangeListener { group, checkedId ->
                selectedIssue = group.findViewById<RadioButton>(checkedId)?.text?.toString() ?: "Not sure"
            }
        }
        page.addView(issueGroup)

        page.addView(text("3. Current sensitivity (optional)", 19f, 0xFF71E6B1.toInt()))
        val currentSens = mutableMapOf<String, Int>()
        listOf("General", "Red Dot", "2x Scope", "4x Scope", "Sniper").forEach { name ->
            page.addView(text("$name:"))
            val valueLabel = text("100", 13f, 0xFFB9C2D0.toInt())
            page.addView(valueLabel)
            page.addView(SeekBar(this).apply {
                max = 200
                progress = 100
                currentSens[name] = 100
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        currentSens[name] = progress
                        valueLabel.text = progress.toString()
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            })
        }

        page.addView(Button(this).apply {
            text = "Generate sensitivity + HUD advice"
            setOnClickListener {
                val advice = GameplayAnalyzer.personalizedAdvice(
                    selectedIssue,
                    currentSens.toMap(),
                    "Samsung Galaxy M34 5G"
                )
                report.text = advice
            }
        }, buttonParams())

        page.addView(text("Analysis report", 19f, 0xFF71E6B1.toInt()))
        report = text("Your recommendations will appear here.", 14f, 0xFFD5DBE5.toInt())
        page.addView(report)

        page.addView(text(
            "Accuracy note: this version samples video frames and reads basic visual statistics. " +
            "It does NOT yet reliably recognize Free Fire enemies, headshots, hit markers or crosshair position. " +
            "True headshot/aim scoring needs a game-specific, labelled vision model validated on your recordings. " +
            "Sensitivity values are starting-point suggestions, not guaranteed best settings.",
            12f,
            0xFFFFD98A.toInt()
        ))

        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun buttonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 10, 0, 10) }

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Activity result API retained for starter compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == videoRequest && resultCode == RESULT_OK && data?.data != null) {
            inspectVideo(data.data!!)
        } else if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("projectionData", data)
            }
            try {
                startForegroundService(service)
                status.text = "Live screen capture is active. Stop it from Android's notification controls."
                Toast.makeText(this, "Screen capture started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                status.text = "Could not start capture: ${e.message}"
            }
        }
    }

    private fun inspectVideo(uri: Uri) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val sample = GameplayAnalyzer.sampleVideo(retriever, duration)
            status.text = "Recording checked: ${duration / 1000}s, ${width}x${height}. ${sample.summary}"
            report.text = sample.details + "\n\n" +
                GameplayAnalyzer.personalizedAdvice(selectedIssue, emptyMap(), "Samsung Galaxy M34 5G")
        } catch (e: Exception) {
            status.text = "Could not read this video: ${e.message}"
        } finally {
            retriever.release()
        }
    }
}
