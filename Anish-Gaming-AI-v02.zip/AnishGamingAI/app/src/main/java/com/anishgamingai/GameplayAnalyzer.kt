package com.anishgamingai

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import kotlin.math.abs
import kotlin.math.max

object GameplayAnalyzer {
    data class VideoSample(val summary: String, val details: String)

    fun sampleVideo(retriever: MediaMetadataRetriever, durationMs: Long): VideoSample {
        if (durationMs <= 0L) return VideoSample("Duration unavailable.", "Could not sample frames.")
        val sampleCount = 6
        val timestamps = (0 until sampleCount).map { i ->
            ((durationMs - 1).coerceAtLeast(0) * i / max(1, sampleCount - 1)).coerceAtLeast(0)
        }
        var brightnessTotal = 0.0
        var contrastTotal = 0.0
        var sampled = 0
        var previous: IntArray? = null
        var motionTotal = 0.0

        timestamps.forEach { time ->
            val bitmap = retriever.getFrameAtTime(time * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            if (bitmap != null) {
                val metrics = frameMetrics(bitmap)
                brightnessTotal += metrics.first
                contrastTotal += metrics.second
                val pixels = scaledLuma(bitmap)
                val old = previous
                if (old != null && old.size == pixels.size) {
                    var diff = 0L
                    for (i in pixels.indices) diff += abs(pixels[i] - old[i])
                    motionTotal += diff.toDouble() / pixels.size
                }
                previous = pixels
                sampled++
                bitmap.recycle()
            }
        }

        if (sampled == 0) return VideoSample("No frames could be sampled.", "Try a standard MP4 recording.")
        val brightness = brightnessTotal / sampled
        val contrast = contrastTotal / sampled
        val motion = if (sampled > 1) motionTotal / (sampled - 1) else 0.0
        val details = "Video frame scan ($sampled sampled frames):\n" +
            "• Average brightness: ${brightness.toInt()}/255\n" +
            "• Average contrast estimate: ${contrast.toInt()}/255\n" +
            "• Frame-to-frame visual change: ${motion.toInt()}/255\n\n" +
            "These are video-quality/motion indicators only; they are not headshot rate, enemy tracking or aim accuracy."
        return VideoSample("Sampled $sampled frames.", details)
    }

    private fun frameMetrics(bitmap: Bitmap): Pair<Double, Double> {
        val w = minOf(bitmap.width, 96)
        val h = minOf(bitmap.height, 96)
        val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
        val pixels = IntArray(w * h)
        small.getPixels(pixels, 0, w, 0, 0, w, h)
        var sum = 0L
        var sumSq = 0.0
        pixels.forEach { p ->
            val l = (0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255))
            sum += l.toLong()
            sumSq += l * l
        }
        val mean = sum.toDouble() / pixels.size
        val variance = (sumSq / pixels.size - mean * mean).coerceAtLeast(0.0)
        if (small !== bitmap) small.recycle()
        return mean to kotlin.math.sqrt(variance)
    }

    private fun scaledLuma(bitmap: Bitmap): IntArray {
        val w = 32
        val h = 32
        val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
        val pixels = IntArray(w * h)
        small.getPixels(pixels, 0, w, 0, 0, w, h)
        small.recycle()
        return pixels.map { p ->
            (0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255)).toInt()
        }.toIntArray()
    }

    fun personalizedAdvice(issue: String, current: Map<String, Int>, device: String): String {
        val baseline = mapOf("General" to 95, "Red Dot" to 90, "2x Scope" to 82, "4x Scope" to 72, "Sniper" to 48)
        val adjustment = when {
            issue.contains("overshoots") -> -8
            issue.contains("below") -> 7
            issue.contains("shakes") -> -10
            issue.contains("slowly") -> 8
            else -> 0
        }
        val adjusted = baseline.mapValues { (key, value) ->
            (current[key] ?: value) + adjustment
        }
        val hud = when {
            issue.contains("overshoots") || issue.contains("below") ->
                "• Keep fire button within comfortable thumb reach.\n• Try a slightly larger fire button (about 48–55%) and practise short upward drags.\n• Keep aim and fire buttons separated enough to avoid accidental presses."
            issue.contains("shakes") ->
                "• Reduce unnecessary button overlap.\n• Try a fire button around 45–50% and use a stable thumb position.\n• Avoid changing sensitivity and HUD at the same time."
            issue.contains("slowly") ->
                "• Move fire button slightly closer to your natural thumb resting point.\n• Try a fire button around 50–55% and practise controlled upward drags."
            else ->
                "• Start with a fire button around 50% as a test, not a fixed best value.\n• Keep jump, crouch and gloo-wall buttons reachable without shifting your aim thumb."
        }
        return "Personalized starting profile for $device\n" +
            "Reported issue: $issue\n\n" +
            "Suggested test sensitivities (0–200 scale):\n" +
            adjusted.entries.joinToString("\n") { "• ${it.key}: ${it.value.coerceIn(0, 200)}" } +
            "\n\nHUD test suggestions:\n$hud\n\n" +
            "Test in Training Ground for 10–15 minutes. Change one setting at a time and compare 3–5 similar fights. " +
            "These are experimental starting values, not measured optimal values. The app has not yet learned your headshot or tracking performance."
    }
}
