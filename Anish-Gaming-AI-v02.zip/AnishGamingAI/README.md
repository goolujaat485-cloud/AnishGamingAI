# Anish Gaming AI – MVP v0.2

Target device profile: Samsung Galaxy M34 5G, 6 GB RAM. The app uses Android-compatible APIs and targets SDK 35; it should run on newer Android versions that permit apps targeting 35, subject to device policy.

## Features included
- Pick a gameplay video through Android's document picker.
- Sample up to six video frames and report basic brightness, contrast and frame-to-frame visual change.
- User-reported aim problem selector.
- Current sensitivity sliders and experimental sensitivity starting-point suggestions.
- HUD/fire-button placement tips.
- User-approved live screen capture through MediaProjection foreground service.

## Important limitations
This version does not reliably detect Free Fire enemies, headshots, hit markers, crosshair position, recoil or headshot percentage. Generic image statistics cannot establish those things. A real AI aim/headshot coach needs a labelled Free Fire gameplay dataset and a trained game-specific vision model (for example, a TFLite model), then testing against varied phones, HUDs, graphics and game updates. Do not treat the current sensitivity suggestions as proven optimal settings.

## Build
GitHub Actions workflow is included at `.github/workflows/build.yml`. Push the project to a GitHub repository and run the workflow. Artifact: `Anish-Gaming-AI-debug`.
